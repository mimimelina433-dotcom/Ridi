# Ridi App - Full-Stack Ride Hailing Application

## Overview
A complete ride-hailing platform with:
- **Backend**: Node.js + Express + MongoDB + JWT + Socket.io (Port 5001)
- **Passenger Client**: React + Vite + Tailwind CSS (Port 5000)
- **Admin Dashboard**: React + Vite + Tailwind CSS (Port 3001)

## Current Status (Oct 16, 2025)
- ✅ Project files moved from uploaded zip to root
- ✅ Node.js 20 installed
- ✅ All dependencies installed (root, backend, client, admin)
- ✅ Vite configured for Replit (0.0.0.0 host binding)
- ✅ Client running on port 5000 (Replit requirement)
- ✅ Backend running on port 5001
- ✅ MongoDB Atlas connected successfully
- ✅ Application fully functional and tested

## Project Structure
```
/
├── backend/          # Express API server
│   ├── src/
│   │   ├── index.js      # Main server file
│   │   ├── models/       # Mongoose models
│   │   ├── routes/       # API routes
│   │   ├── middleware/   # Auth & other middleware
│   │   └── socket.js     # Socket.io setup
│   └── package.json
├── client/           # Passenger frontend (React)
│   ├── src/
│   └── package.json
├── admin/            # Admin dashboard (React)
│   ├── src/
│   └── package.json
└── package.json      # Root (concurrently)
```

## Environment Configuration

### Replit Environment
- **Frontend URL**: https://eed93f0f-2e59-43dd-b3e5-9c5e6a6c7481-00-2mrcl7spl5h8i.spock.replit.dev (port 5000)
- **Backend URL**: https://eed93f0f-2e59-43dd-b3e5-9c5e6a6c7481-00-2mrcl7spl5h8i.spock.replit.dev:5001

### Required Secrets (in Replit Secrets)
- `MONGO_URI`: MongoDB Atlas connection string

### Environment Files Created
- `/backend/.env`: PORT=5001, JWT_SECRET
- `/client/.env`: VITE_REACT_APP_API_BASE (points to backend on port 5001)
- `/admin/.env`: REACT_APP_API_BASE (points to backend on port 5001)

## Setup Instructions

### MongoDB Atlas Configuration (REQUIRED)
1. Go to MongoDB Atlas → Network Access
2. Click "Add IP Address"
3. Either:
   - Add `0.0.0.0/0` (allows all IPs - for development only)
   - Or add Replit's specific IP address
4. Save and wait 1-2 minutes for changes to propagate
5. Restart the workflow in Replit

### Running the App
- **Main workflow**: `npm run dev` (starts backend + client concurrently)
- **Backend only**: `npm run backend`
- **Client only**: `npm run passenger`
- **Admin only**: `npm run admin`

## Key Technical Decisions

### Port Configuration
- **Port 5000**: Client frontend (REQUIRED by Replit for webview)
- **Port 5001**: Backend API (accessible via domain:5001)
- **Port 3001**: Admin dashboard (not auto-proxied, needs manual access)

### Vite Configuration
- Client and Admin both configured with `host: '0.0.0.0'` for Replit compatibility
- Client uses `strictPort: true` to ensure port 5000

### API Communication
- Frontend apps use environment variables to find backend
- Client: `VITE_REACT_APP_API_BASE`
- Admin: `REACT_APP_API_BASE`
- Both point to Replit domain with port 5001

## Known Issues & Next Steps

### Active Issues
1. **MongoDB Connection Blocked**: Atlas IP whitelist needs Replit IP
   - Error: "Could not connect to any servers in your MongoDB Atlas cluster"
   - Solution: Add IP to Atlas Network Access settings

### Admin Dashboard Access
- Currently on port 3001 (not auto-proxied by Replit)
- Consider: Proxying through backend or reconfiguring to share port 5000

## Dependencies Installed
- **Root**: concurrently
- **Backend**: express, mongoose, dotenv, cors, morgan, socket.io, jsonwebtoken, bcryptjs, nodemon
- **Client**: react, react-dom, react-router-dom, axios, leaflet, socket.io-client, vite, tailwindcss
- **Admin**: react, react-dom, react-router-dom, axios, socket.io-client, vite, tailwindcss

## User Preferences
- Using MongoDB Atlas for database (free tier)
- Development environment on Replit
