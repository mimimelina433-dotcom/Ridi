#!/usr/bin/env bash
# create_and_push_github_repo.sh
# Creates a public GitHub repo called ridiapp-platform under the authenticated GH account,
# initializes git, commits all files and pushes to main.
# Requirements: git, gh (GitHub CLI), gh auth login must be done prior to running.
set -euo pipefail

REPO_NAME="ridiapp-platform"
COMMIT_MSG="Initial commit - Full Ridi App (Passenger + Admin + Backend)"

# Check gh installed
if ! command -v gh >/dev/null 2>&1; then
  echo "ERROR: gh (GitHub CLI) not found. Install and authenticate first: https://github.com/cli/cli"
  exit 2
fi

# Check git installed
if ! command -v git >/dev/null 2>&1; then
  echo "ERROR: git not found. Install git and retry."
  exit 2
fi

# Ensure we're in repo root (script must be run from workspace root)
ROOT_DIR="$(pwd)"
echo "Working directory: $ROOT_DIR"

# Prevent accidental running inside an existing git repo
if [ -d ".git" ]; then
  echo "A .git folder already exists in this directory. To avoid overwriting, the script will abort."
  echo "If you want to use this script anyway, remove or move .git and re-run."
  exit 3
fi

# Create GitHub repo (public) via gh CLI
echo "Creating GitHub repository '${REPO_NAME}' (public) under your account..."
# gh will return url in JSON if created
CREATE_OUTPUT="$(gh repo create "$REPO_NAME" --public --confirm --source=. --remote=origin 2>&1 || true)"
echo "$CREATE_OUTPUT"

# Fallback: if remote not set by gh create, add remote
if ! git remote get-url origin >/dev/null 2>&1; then
  # Try to find owner
  OWNER="$(gh api user --jq .login 2>/dev/null || echo '')"
  if [ -n "$OWNER" ]; then
    REMOTE_URL="https://github.com/${OWNER}/${REPO_NAME}.git"
    git remote add origin "$REMOTE_URL"
    echo "Added origin remote: $REMOTE_URL"
  else
    echo "Could not determine GH owner. Please add remote origin manually and push."
  fi
fi

# Initialize local git repo, add and commit
echo "Initializing local git repository..."
git init
git add --all
git commit -m "$COMMIT_MSG" || { echo "No changes to commit or commit failed."; }

# Ensure main branch name
git branch -M main

# Push to GitHub
echo "Pushing to origin main..."
git push -u origin main

# Print resulting repo URL
if git remote get-url origin >/dev/null 2>&1; then
  ORIGIN_URL="$(git remote get-url origin)"
  echo "Repository pushed successfully."
  # Convert git URL to https web URL if needed
  WEB_URL="$ORIGIN_URL"
  WEB_URL="${WEB_URL%.git}"
  WEB_URL="${WEB_URL/git@github.com:/https://github.com/}"
  echo "Repository URL: $WEB_URL"
else
  echo "Push completed but could not determine the remote URL. Please check manually."
fi

echo "Done."