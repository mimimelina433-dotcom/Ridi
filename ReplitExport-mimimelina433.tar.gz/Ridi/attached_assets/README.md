```markdown
# Ridi App — Full-Stack (Backend, Passenger client, Admin dashboard)

This repository contains a full-stack ride-hailing scaffold:
- Backend: Node.js + Express + MongoDB + JWT + Socket.io
- Passenger client: React + Vite + Tailwind CSS (http://localhost:3000)
- Admin dashboard: React + Vite + Tailwind CSS (http://localhost:3001)
- Docker Compose to run backend, MongoDB, and both frontends (optional)

Important: This scaffold is for development and demo purposes.

Quick start (local / Node):
1. Copy `.env.example` to `.env` and edit values if needed.
2. Install root dev dependency and subproject deps:
   - npm install
   - cd backend && npm install
   - cd ../client && npm install
   - cd ../admin && npm install
3. From root run (starts backend + client + admin concurrently):
   - npm run dev
4. Open:
   - Passenger: http://localhost:3000
   - Admin: http://localhost:3001
   - Backend health: http://localhost:5000/api/health

Quick start (Docker Compose):
1. Ensure Docker & docker-compose are installed.
2. Copy `.env.example` to `.env` and edit if needed.
3. From root run:
   - docker-compose up --build
4. Access same URLs.

Project structure (top-level):
- backend/
- client/
- admin/
- docker-compose.yml
- README.md
- .env.example

Notes:
- Default JWT secret and DB URI are for development only.
- The backend includes a small seed script to create an admin user and sample drivers/users.
- The frontends use REACT_APP_API_BASE environment variable to target the backend (default: http://localhost:5000).

If you'd like, I can:
- Provide a single downloadable ZIP file (I can output a script to generate it locally).
- Add production build & nginx configs.
- Add Paywall or ephemeral keys.
