import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Home from './pages/Home';
import RequestRide from './pages/RequestRide';
import RideStatus from './pages/RideStatus';
import History from './pages/History';
import Profile from './pages/Profile';

export default function App() {
  return (
    <BrowserRouter>
      <div className="app-container">
        <header className="mb-4">
          <h1 className="text-3xl font-bold text-white">Ridi - Passenger</h1>
          <nav className="mt-2">
            <Link className="mr-4 text-white" to="/">Home</Link>
            <Link className="mr-4 text-white" to="/history">History</Link>
            <Link className="text-white" to="/profile">Profile</Link>
          </nav>
        </header>

        <main className="bg-white p-6 rounded-lg shadow-lg">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/request" element={<RequestRide />} />
            <Route path="/ride/:id" element={<RideStatus />} />
            <Route path="/history" element={<History />} />
            <Route path="/profile" element={<Profile />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  );
}