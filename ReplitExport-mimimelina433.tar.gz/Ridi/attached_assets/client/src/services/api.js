import axios from 'axios';
const baseURL = import.meta.env.VITE_REACT_APP_API_BASE || process.env.REACT_APP_API_BASE || 'http://localhost:5000';
export const api = axios.create({ baseURL: baseURL + '/api' });

export function setAuthToken(token) {
  api.defaults.headers.common['Authorization'] = token ? `Bearer ${token}` : '';
}