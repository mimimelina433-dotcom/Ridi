import React, { useEffect } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

export default function Map(){
  useEffect(() => {
    const map = L.map('map').setView([36.7538, 3.0588], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);
    const marker = L.marker([36.7538, 3.0588]).addTo(map);
    marker.bindPopup('Algiers center').openPopup();
    return () => map.remove();
  }, []);

  return (<div id="map" style={{ height: 360, borderRadius: 8 }} />);
}