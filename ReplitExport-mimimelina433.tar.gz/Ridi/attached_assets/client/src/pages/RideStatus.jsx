import React, { useEffect, useState } from 'react';
import { api } from '../services/api';
import { useParams } from 'react-router-dom';
import io from 'socket.io-client';

export default function RideStatus(){
  const { id } = useParams();
  const [ride, setRide] = useState(null);

  useEffect(() => {
    async function load(){ const res = await api.get(`/rides/${id}`); setRide(res.data); }
    load();
    const socket = io(import.meta.env.VITE_REACT_APP_API_BASE || process.env.REACT_APP_API_BASE || 'http://localhost:5000');
    // Identify as passenger if token & user id available (optional)
    socket.on('ride:accepted', data => { if (data.rideId === id) load(); });
    return () => socket.disconnect();
  }, [id]);

  if (!ride) return <div>Loading...</div>;

  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">Ride Status</h2>
      <div>Status: {ride.status}</div>
      <div>Fare: {ride.fare} DZD</div>
      <div>Driver: {ride.driver? ride.driver.name : 'Unassigned'}</div>
    </div>
  );
}