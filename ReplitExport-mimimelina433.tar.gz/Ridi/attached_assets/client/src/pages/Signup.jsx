import React, { useState } from 'react';
import { api } from '../services/api';
import { useNavigate } from 'react-router-dom';

export default function Signup(){
  const [name,setName]=useState(''); const [email,setEmail]=useState(''); const [password,setPassword]=useState('');
  const nav = useNavigate();

  async function submit(e){
    e.preventDefault();
    try {
      const res = await api.post('/auth/register', { name, email, password });
      localStorage.setItem('ridi_token', res.data.token);
      nav('/');
    } catch (err) {
      alert('Signup failed');
    }
  }

  return (<div>
    <h2 className="text-xl font-bold mb-4">Sign up</h2>
    <form onSubmit={submit}>
      <input className="border p-2 w-full mb-2" placeholder="Name" value={name} onChange={e=>setName(e.target.value)} />
      <input className="border p-2 w-full mb-2" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
      <input type="password" className="border p-2 w-full mb-2" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} />
      <button className="bg-gradient-to-r from-[#FD1D1D] via-[#833AB4] to-[#FCB045] text-white px-4 py-2 rounded">Sign up</button>
    </form>
  </div>);
}