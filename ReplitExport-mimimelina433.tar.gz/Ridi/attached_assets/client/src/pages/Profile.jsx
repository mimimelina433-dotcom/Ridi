import React, { useEffect, useState } from 'react';
import { api } from '../services/api';

export default function Profile(){
  const [me, setMe] = useState(null);
  useEffect(()=>{ api.get('/users/me').then(res=>setMe(res.data)); }, []);
  if (!me) return <div>Loading...</div>;
  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">Profile</h2>
      <div>Name: {me.name}</div>
      <div>Email: {me.email}</div>
    </div>
  );
}