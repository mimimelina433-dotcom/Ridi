import React, { useEffect, useState } from 'react';
import { api } from '../services/api';

export default function History(){
  const [rides, setRides] = useState([]);
  useEffect(()=>{ api.get('/rides').then(res=>setRides(res.data)); }, []);
  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">Your Rides</h2>
      <ul>
        {rides.map(r => <li key={r._id} className="border p-2 mb-2">{r.pickup?.address} → {r.dropoff?.address} • {r.status}</li>)}
      </ul>
    </div>
  );
}