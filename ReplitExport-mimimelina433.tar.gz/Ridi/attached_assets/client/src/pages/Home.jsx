import React from 'react';
import Map from '../components/Map';
import { Link } from 'react-router-dom';

export default function Home(){
  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">Request a Ride</h2>
      <Map />
      <div className="mt-4">
        <Link to="/request" className="inline-block bg-gradient-to-r from-[#FD1D1D] via-[#833AB4] to-[#FCB045] text-white px-4 py-2 rounded">Request Ride</Link>
      </div>
    </div>
  );
}