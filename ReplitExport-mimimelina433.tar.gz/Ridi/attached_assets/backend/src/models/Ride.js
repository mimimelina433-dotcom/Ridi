// backend/src/models/Ride.js
const mongoose = require('mongoose');

const RideSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  driver: { type: mongoose.Schema.Types.ObjectId, ref: 'Driver' },
  pickup: { address: String, coordinates: [Number] }, // [lng, lat]
  dropoff: { address: String, coordinates: [Number] },
  status: { type: String, enum: ['requested', 'accepted', 'on_trip', 'completed', 'cancelled'], default: 'requested' },
  fare: { type: Number, default: 0 },
  paymentMethod: { type: String, default: 'cash' },
  createdAt: { type: Date, default: Date.now },
  completedAt: Date
});

module.exports = mongoose.model('Ride', RideSchema);