// backend/src/routes/users.js
const express = require('express');
const router = express.Router();
const { authMiddleware, adminOnly } = require('../middleware/auth');
const User = require('../models/User');

router.get('/', authMiddleware, adminOnly, async (req, res) => {
  const users = await User.find().select('-passwordHash');
  res.json(users);
});

router.get('/me', authMiddleware, async (req, res) => {
  const u = req.user;
  res.json({ id: u._id, name: u.name, email: u.email, phone: u.phone, role: u.role });
});

router.put('/:id', authMiddleware, adminOnly, async (req, res) => {
  const upd = req.body;
  const u = await User.findByIdAndUpdate(req.params.id, upd, { new: true }).select('-passwordHash');
  res.json(u);
});

router.delete('/:id', authMiddleware, adminOnly, async (req, res) => {
  await User.findByIdAndDelete(req.params.id);
  res.json({ ok: true });
});

module.exports = router;