// backend/src/routes/admin.js
const express = require('express');
const router = express.Router();
const { authMiddleware, adminOnly } = require('../middleware/auth');
const User = require('../models/User');
const Driver = require('../models/Driver');
const Ride = require('../models/Ride');

router.get('/stats', authMiddleware, adminOnly, async (req, res) => {
  const totalUsers = await User.countDocuments();
  const totalDrivers = await Driver.countDocuments();
  const totalRides = await Ride.countDocuments();
  res.json({ totalUsers, totalDrivers, totalRides });
});

module.exports = router;