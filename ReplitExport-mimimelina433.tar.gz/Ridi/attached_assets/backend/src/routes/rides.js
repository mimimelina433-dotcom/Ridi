// backend/src/routes/rides.js
const express = require('express');
const router = express.Router();
const { authMiddleware, adminOnly } = require('../middleware/auth');
const Ride = require('../models/Ride');
const Driver = require('../models/Driver');
const { notifyDrivers, notifyPassenger } = require('../socket');

// create ride (passenger)
router.post('/', authMiddleware, async (req, res) => {
  try {
    const { pickup, dropoff, fare } = req.body;
    const ride = new Ride({ user: req.user._id, pickup, dropoff, fare });
    await ride.save();

    // Notify available drivers (simple broadcast for demo)
    notifyDrivers([], 'ride:new', ride);

    res.json(ride);
  } catch (err) {
    res.status(500).json({ message: 'Create ride failed' });
  }
});

// get my rides
router.get('/', authMiddleware, async (req, res) => {
  const rides = await Ride.find({ user: req.user._id }).populate('driver user');
  res.json(rides);
});

// admin list
router.get('/all', authMiddleware, adminOnly, async (req, res) => {
  const rides = await Ride.find().populate('driver user').sort({ createdAt: -1 });
  res.json(rides);
});

// accept ride (driver)
router.post('/:id/accept', async (req, res) => {
  try {
    const { driverId } = req.body;
    const ride = await Ride.findById(req.params.id);
    if (!ride) return res.status(404).json({ message: 'Ride not found' });
    ride.driver = driverId;
    ride.status = 'accepted';
    await ride.save();

    // notify passenger via socket
    notifyPassenger(ride.user.toString(), 'ride:accepted', { rideId: ride._id, driverId });

    res.json(ride);
  } catch (err) {
    res.status(500).json({ message: 'Accept failed' });
  }
});

// update status
router.put('/:id', authMiddleware, async (req, res) => {
  const ride = await Ride.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(ride);
});

module.exports = router;