// backend/src/routes/drivers.js
const express = require('express');
const router = express.Router();
const { authMiddleware, adminOnly } = require('../middleware/auth');
const Driver = require('../models/Driver');

// List drivers (admin)
router.get('/', authMiddleware, adminOnly, async (req, res) => {
  const drivers = await Driver.find();
  res.json(drivers);
});

// Create driver (public for demo)
router.post('/', async (req, res) => {
  const d = new Driver(req.body);
  await d.save();
  res.json(d);
});

router.put('/:id', authMiddleware, adminOnly, async (req, res) => {
  const d = await Driver.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(d);
});

router.delete('/:id', authMiddleware, adminOnly, async (req, res) => {
  await Driver.findByIdAndDelete(req.params.id);
  res.json({ ok: true });
});

module.exports = router;