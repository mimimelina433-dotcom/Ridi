// backend/src/seed.js
// Simple seeder to create an admin user and sample drivers/users
require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('./models/User');
const Driver = require('./models/Driver');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/ridiapp';

async function seed() {
  await mongoose.connect(MONGO_URI);
  console.log('Connected to MongoDB', MONGO_URI);
  await User.deleteMany({});
  await Driver.deleteMany({});

  const adminPass = await bcrypt.hash('admin123', 10);
  const admin = new User({ name: 'Admin', email: 'admin@ridi.app', passwordHash: adminPass, role: 'admin' });
  await admin.save();

  const userPass = await bcrypt.hash('user123', 10);
  const user = new User({ name: 'Ahmed', email: 'ahmed@ridi.app', passwordHash: userPass, role: 'user' });
  await user.save();

  const d1 = new Driver({ name: 'Omar', phone: '+21360000001', vehicle: 'Toyota', approved: true });
  const d2 = new Driver({ name: 'Sara', phone: '+21360000002', vehicle: 'Hyundai', approved: true });
  await d1.save(); await d2.save();

  console.log('Seed done. Admin credentials: admin@ridi.app / admin123');
  process.exit(0);
}

seed().catch(err => { console.error(err); process.exit(1); });