// backend/src/socket.js
const { Server } = require('socket.io');
let io;
const driverSockets = new Map();
const passengerSockets = new Map();

function initSocket(server) {
  io = new Server(server, { cors: { origin: "*" } });

  io.on('connection', (socket) => {
    console.log('socket connected', socket.id);

    socket.on('identify', ({ type, id }) => {
      if (type === 'driver') {
        driverSockets.set(String(id), socket.id);
        socket.join(`driver:${id}`);
      } else if (type === 'passenger') {
        passengerSockets.set(String(id), socket.id);
        socket.join(`user:${id}`);
      } else if (type === 'admin') {
        socket.join('admin_room');
      }
    });

    socket.on('disconnect', () => {
      for (const [k, v] of driverSockets.entries()) if (v === socket.id) driverSockets.delete(k);
      for (const [k, v] of passengerSockets.entries()) if (v === socket.id) passengerSockets.delete(k);
      console.log('socket disconnected', socket.id);
    });
  });

  return io;
}

function notifyDrivers(driverIds, event, payload) {
  if (!io) return;
  if (Array.isArray(driverIds) && driverIds.length) {
    driverIds.forEach(id => {
      const sid = driverSockets.get(String(id));
      if (sid) io.to(sid).emit(event, payload);
    });
  } else {
    io.emit(event, payload);
  }
}

function notifyPassenger(userId, event, payload) {
  if (!io) return;
  const sid = passengerSockets.get(String(userId));
  if (sid) io.to(sid).emit(event, payload);
}

module.exports = { initSocket, notifyDrivers, notifyPassenger };