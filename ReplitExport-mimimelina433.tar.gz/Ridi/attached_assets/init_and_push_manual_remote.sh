#!/usr/bin/env bash
# init_and_push_manual_remote.sh
# Initializes git, commits and pushes to a provided remote URL.
set -euo pipefail

if [ $# -lt 1 ]; then
  echo "Usage: $0 <remote-git-url>"
  echo "Example: $0 https://github.com/Badru21/ridiapp-platform.git"
  exit 1
fi

REMOTE_URL="$1"
COMMIT_MSG="Initial commit - Full Ridi App (Passenger + Admin + Backend)"

if [ -d ".git" ]; then
  echo "Existing .git found. Aborting to avoid overwriting."
  exit 2
fi

git init
git add --all
git commit -m "$COMMIT_MSG" || { echo "No changes to commit."; }

git branch -M main
git remote add origin "$REMOTE_URL"
git push -u origin main

echo "Pushed to $REMOTE_URL"