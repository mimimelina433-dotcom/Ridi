import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Users from './pages/Users';
import Drivers from './pages/Drivers';
import Rides from './pages/Rides';

export default function App() {
  return (
    <BrowserRouter>
      <div className="container">
        <header className="mb-6">
          <h1 className="text-2xl font-bold">Ridi Admin</h1>
          <nav className="mt-2">
            <Link className="mr-4" to="/">Dashboard</Link>
            <Link className="mr-4" to="/users">Users</Link>
            <Link className="mr-4" to="/drivers">Drivers</Link>
            <Link to="/rides">Rides</Link>
          </nav>
        </header>

        <main className="card">
          <Routes>
            <Route path="/" element={<Dashboard/>} />
            <Route path="/login" element={<Login/>} />
            <Route path="/users" element={<Users/>} />
            <Route path="/drivers" element={<Drivers/>} />
            <Route path="/rides" element={<Rides/>} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  );
}