import React, { useEffect, useState } from 'react';
import axios from 'axios';
export default function Drivers(){
  const [drivers,setDrivers]=useState([]);
  useEffect(()=>{ axios.get((process.env.REACT_APP_API_BASE||'http://localhost:5000') + '/api/drivers', { headers:{ Authorization: 'Bearer ' + localStorage.getItem('ridi_admin_token') } }).then(r=>setDrivers(r.data)).catch(()=>{}); }, []);
  return (<div><h2 className="text-xl mb-4">Drivers</h2><ul>{drivers.map(d=> <li key={d._id} className="border p-2 mb-2">{d.name} • {d.vehicle} • {d.approved ? 'Approved' : 'Pending'}</li>)}</ul></div>);
}