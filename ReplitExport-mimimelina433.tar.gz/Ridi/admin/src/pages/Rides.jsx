import React, { useEffect, useState } from 'react';
import axios from 'axios';
export default function Rides(){
  const [rides,setRides]=useState([]);
  useEffect(()=>{ axios.get((process.env.REACT_APP_API_BASE||'http://localhost:5000') + '/api/rides/all', { headers:{ Authorization: 'Bearer ' + localStorage.getItem('ridi_admin_token') } }).then(r=>setRides(r.data)).catch(()=>{}); }, []);
  return (<div><h2 className="text-xl mb-4">Rides</h2><ul>{rides.map(r=> <li key={r._id} className="border p-2 mb-2">{r.user?.name} • {r.pickup?.address} → {r.dropoff?.address} • {r.status}</li>)}</ul></div>);
}