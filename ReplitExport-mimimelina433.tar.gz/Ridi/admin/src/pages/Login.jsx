import React, { useState } from 'react';
import axios from 'axios';

export default function Login(){
  const [email,setEmail]=useState('admin@ridi.app'); const [password,setPassword]=useState('admin123');
  async function submit(e){
    e.preventDefault();
    try {
      const res = await axios.post((process.env.REACT_APP_API_BASE || 'http://localhost:5000') + '/api/auth/login', { email, password });
      localStorage.setItem('ridi_admin_token', res.data.token);
      window.location.href = '/';
    } catch (err){
      alert('Login failed');
    }
  }
  return (<div>
    <h2 className="text-xl mb-4">Admin Login</h2>
    <form onSubmit={submit}>
      <input className="border p-2 w-full mb-2" value={email} onChange={e=>setEmail(e.target.value)} />
      <input className="border p-2 w-full mb-2" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
      <button className="bg-indigo-600 text-white px-4 py-2 rounded">Login</button>
    </form>
  </div>);
}