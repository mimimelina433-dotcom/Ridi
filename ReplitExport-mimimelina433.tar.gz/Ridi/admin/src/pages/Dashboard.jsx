import React, { useEffect, useState } from 'react';
import axios from 'axios';
export default function Dashboard(){
  const [stats,setStats]=useState(null);
  useEffect(()=>{ axios.get((process.env.REACT_APP_API_BASE||'http://localhost:5000') + '/api/admin/stats', { headers: { Authorization: 'Bearer ' + localStorage.getItem('ridi_admin_token') }}).then(r=>setStats(r.data)).catch(()=>{}); },[]);
  return (<div>
    <h2 className="text-xl font-semibold mb-4">Dashboard</h2>
    {stats ? <div className="grid grid-cols-3 gap-4">
      <div className="p-4 bg-gray-900 rounded">Users<br/><strong>{stats.totalUsers}</strong></div>
      <div className="p-4 bg-gray-900 rounded">Drivers<br/><strong>{stats.totalDrivers}</strong></div>
      <div className="p-4 bg-gray-900 rounded">Rides<br/><strong>{stats.totalRides}</strong></div>
    </div> : <div>Loading...</div>}
  </div>);
}