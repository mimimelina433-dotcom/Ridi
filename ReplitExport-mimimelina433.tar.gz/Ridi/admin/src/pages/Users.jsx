import React, { useEffect, useState } from 'react';
import axios from 'axios';
export default function Users(){
  const [users,setUsers]=useState([]);
  useEffect(()=>{ axios.get((process.env.REACT_APP_API_BASE||'http://localhost:5000') + '/api/users', { headers:{ Authorization: 'Bearer ' + localStorage.getItem('ridi_admin_token') } }).then(r=>setUsers(r.data)).catch(()=>{}); }, []);
  return (<div><h2 className="text-xl mb-4">Users</h2><ul>{users.map(u=> <li key={u._id} className="border p-2 mb-2">{u.name} • {u.email}</li>)}</ul></div>);
}